# zed2i_vslam — RoboSub Positional Tracking Node

Optimized ZED2i tracking stack for RoboSub competition runs.

## What it does

```
ZED SDK (IMU @ 400 Hz)
       │
ZED ROS2 Wrapper
       │  /zed2i/zed_node/pose  (map frame, VSLAM + loop closure)
       │  /zed2i/zed_node/odom  (odom frame, VIO, higher rate)
       │  /zed2i/zed_node/imu/data
       ▼
zed2i_vslam_node
       │  Jerk rejection (suppresses single-frame spikes)
       │  Velocity smoothing (10-frame window)
       │  Path accumulation (up to 3000 poses)
       ▼
~/filtered_pose        — map-frame pose, jerk-suppressed
~/filtered_odom        — odom-frame odometry, jerk-suppressed
~/path_map             — full trajectory in map frame  ← RViz green line
~/path_odom            — odometry path (shows drift)   ← RViz orange line
~/velocity_mps         — smoothed speed scalar
~/jerk_events          — RViz sphere markers at large-motion events
~/diagnostics          — health stats (pose count, jerk events, velocity)
```

## Quick start

```bash
# Build
cd ~/robosub2026/robosub-2026
colcon build --packages-select zed2i_vslam --symlink-install
source install/local_setup.bash

# Run everything (ZED wrapper + tracking node + RViz)
ros2 launch zed2i_vslam robosub_tracking.launch.py

# Run without RViz (headless)
ros2 launch zed2i_vslam robosub_tracking.launch.py rviz:=false

# Replay an SVO recording
ros2 launch zed2i_vslam robosub_tracking.launch.py svo_path:=/path/to/run.svo2

# Pre-load a mapped pool for faster re-localization
ros2 launch zed2i_vslam robosub_tracking.launch.py area_memory_path:=/path/to/pool.area
```

## Tuning jerk thresholds

Edit `config/vslam_node.yaml`:

```yaml
jerk_distance_thresh: 0.35   # metres/frame — lower = stricter
jerk_angle_thresh: 0.50      # radians/frame
jerk_hold_frames: 2          # consecutive bad frames before accepting as real
```

**RoboSub rules of thumb:**
- Max AUV sprint ~1.5 m/s → ~0.05 m/frame at 30 Hz
- `jerk_distance_thresh: 0.35` gives ~7× headroom before rejection kicks in
- If the AUV does very fast turns, increase `jerk_angle_thresh` slightly

## Topics to subscribe to from other nodes

| Topic | Type | Use |
|---|---|---|
| `~/filtered_pose` | `geometry_msgs/PoseStamped` | Mission planner, control loop |
| `~/filtered_odom` | `nav_msgs/Odometry` | Control loop (higher rate) |
| `~/velocity_mps`  | `std_msgs/Float32` | Speed monitoring |

## RViz layout

- **Green line** = map-frame path (VSLAM + loop closure corrected)
- **Orange line** = odometry path (raw VIO, drifts over time — useful for comparison)
- **Green arrow** = current filtered pose
- **Orange arrow** = current filtered odometry
- **Orange spheres** = locations where large motion events were detected
- **TF tree** = map → odom → base_link → zed2i_camera_link
